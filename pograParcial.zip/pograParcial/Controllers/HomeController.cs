﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using pograParcial.Models;


namespace pograParcial.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        
        public IActionResult FormularioContacto()
        {
            return View();
        }

         public IActionResult CatalogoProductos()
        {
            return View();
        }
         public IActionResult PagarCompra()
        {
            return View();
        }
         public IActionResult QuienesSomos()
        {
            return View();
        }
         public IActionResult ProductosDestacados()
        {
            return View();
        }
         public IActionResult ResumenCompra()
        {
            return View();
        }
         public IActionResult Servicios()
        {
            return View();
        }
         public IActionResult ServiciosyProductos()
        {
            return View();
        }
         public IActionResult Registro()
        {
            return View();
        }
         public IActionResult ActualizarPerfil()
        {
            return View();
        }
         public IActionResult IniciarSesion()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
public  IActionResult ContactoCrear(Contacto objContacto){

              
             objContacto.Mensaje = "Hola "+ objContacto.Nombres+"\n"+"Tu Mensaje" +" con motivo "+ "''"+objContacto.Motivo+"''"+" ha sido enviado con éxito. \n";
            
             return View("FormularioContacto",objContacto);   
             }

        


    }
}
