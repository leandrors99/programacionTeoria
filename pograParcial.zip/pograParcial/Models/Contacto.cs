using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace pograParcial.Models
{
   
    public class Contacto{

       
        public string Nombres { get; set; }
       
        public string Mensaje { get; set; }
        
        public string Apellidos { get; set; }
      
        public String Correo { get; set; }

        public String Motivo { get; set; }
       
        public int Mensaje1 { get; set; }


    }

}